BFVDesktop 0.84 - Dated 12 Aug 2021

Copyright (C) 2021 Alistair Dickie

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.




Introduction

A java desktop program to modify the settings on the BlueFlyVario (www.blueflyvario.com)


Basic Usage

1. You need a Java Virtual Machine installed to use this program. Visit java.com to get one for your operating system. 
2. Run the application by double clicking the BFV_Desktop.jar file or Run.bat in windows 
3. Connect to a BlueFlyVario by selecting the appropriate serial port.
4. Alter the settings (see https://www.blueflyvario.com/support/ for a description of the hardware settings).